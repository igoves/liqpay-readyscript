<?php
/**
 * ReadyScript (http://readyscript.ru)
 *
 * @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
 * @license http://readyscript.ru/licenseAgreement/
 */

namespace Liqpay\Model\PaymentType;
use Catalog\Model\Orm\Currency;
use RS\Orm\FormObject;
use RS\Orm\PropertyIterator;
use RS\Orm\Request;
use \RS\Orm\Type;
use RS\Router\Manager;
use Shop\Model\Orm\Transaction;
use Shop\Model\PaymentType\AbstractType;


/**
 * Payment method liqpay process
 *
 * @author      Igor Veselov <dev@xfor.top>
 */
class LiqPay extends AbstractType
{

    private $_checkout_url = 'https://www.liqpay.ua/api/3/checkout';

    /**
     * Name payment
     *
     * @return string
     */
    function getTitle()
    {
        return t('LiqPay');
    }

    /**
     * Description payment
     *
     * @return string
     */
    function getDescription()
    {
        return t('Приём платежей через LiqPay');
    }

    /**
     * Return id type of payment
     *
     * @return string
     */
    function getShortName()
    {
        return 'liqpay';
    }

    /**
     * Send data by method Post
     *
     */
    function isPostQuery()
    {
        return true;
    }


    /**
     * Return ORM object to generate form or null
     *
     * @return FormObject | null
     */
    function getFormObject()
    {
        $properties = new PropertyIterator(array(
            'public_key' => new Type\Varchar(array(
                'maxLength' => 255,
                'description' => t('public_key'),

            )),
            'private_key' => new Type\Varchar(array(
                'maxLength' => 255,
                'description' => t('private_key'),

            )),
            'language' => new Type\Varchar(array(
                'maxLength' => 5,
                'description' => t('Язык интерфейса'),
                'listFromArray' => array(array(
                    0    => t('Определяется LiqPay'),
                    'ru' => t('Русский'),
                    'ua' => t('Украинский'),
                    'en' => t('Английский'),
                ))
            )),
        ));

        return new FormObject($properties);
    }


    /**
     * Return true, if can oline pay
     *
     * @return bool
     */
    function canOnlinePay()
    {
        return true;
    }

    /**
     * Возвращает URL для перехода на сайт сервиса оплаты
     *
     * @param Transaction $transaction
     * @return string
     */
    function getPayUrl(Transaction $transaction)
    {
        $order      = $transaction->getOrder();
        $private_key = $this->getOption('private_key');
        $public_key = $this->getOption('public_key');
        $language = $this->getOption('language') != 0 ? $this->getOption('language') : '' ;
        $result_url = Manager::obj()->getUrl('main.index', [], true);

        $params = array();
        $params['version'] = 3;
        $params['public_key'] = $public_key;
        $params['action'] = 'pay';
        $params['amount'] = number_format($transaction->cost, 2, '.', '');
        $params['currency'] = $this->getPaymentCurrency();
        $params['description'] = t("Оплата заказа №").$order['order_num'];
        $params['order_id'] = $transaction->id;
        $params['language'] = $language; // ru, uk, en
        $params['result_url'] = $result_url;
//        $params['server_url'] = $result_url;

        $data = $this->encode_params(array_merge(compact('public_key'), $params));
        $signature = $this->str_to_sign($private_key.$data.$private_key);

        $postfields  = array(
            'data'  => $data,
            'signature' => $signature
        );

        $this->addPostParams($postfields);

        return $this->_checkout_url;
    }

    /**
     * Возвращает ID заказа исходя из REQUEST-параметров соотвествующего типа оплаты
     * Используется только для Online-платежей
     *
     * @return mixed
     */
    function getTransactionIdFromRequest(\RS\Http\Request $request)
    {
        return $request->request('order_id', TYPE_STRING);
    }


    function onResult(\Shop\Model\Orm\Transaction $transaction, \RS\Http\Request $request)
    {
        return 'SUCCESS';
    }

    /**
     * Получает трех символьный код базовой валюты в которой ведётся оплата
     *
     */
    private function getPaymentCurrency()
    {
        /**
         * @var Currency
         */
        $currency = Request::make()
            ->from(new Currency())
            ->where(array(
                'public'  => 1,
                'is_base'  => 1,
            ))
            ->object();
        return $currency ? $currency->title : false;
    }


    /**
     * encode_params
     *
     * @param array $params
     * @return string
     */
    private function encode_params($params)
    {
        return base64_encode(json_encode($params));
    }


    /**
     * str_to_sign
     *
     * @param string $str
     *
     * @return string
     */
    public function str_to_sign($str)
    {
        $signature = base64_encode(sha1($str, 1));
        return $signature;
    }

    /**
     * Вызывается при открытии страницы неуспешного проведения платежа
     * Используется только для Online-платежей
     *
     * @param \Shop\Model\Orm\Transaction $transaction
     * @param \RS\Http\Request $request
     * @return void
     */
    function onFail(\Shop\Model\Orm\Transaction $transaction, \RS\Http\Request $request)
    {
        $transaction['status'] = $transaction::STATUS_FAIL;
        $transaction->update();
    }

}